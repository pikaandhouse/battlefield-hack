import torch 
from predict import  forecast
from eval import evaluate
#x = torch.randn([2, 3, 4])
#print(x.shape)
import torch
a = torch.rand(1, 10, 1, 0)
# 使用rand随机均匀初始化一个4维的tensor
# 在minist中可以理解为load进了4张灰度图片，长宽各为28
a=a.squeeze(axis=2)

#x_transposed = x.transpose(-1,1)
#print(x_transposed.shape)
evaluate("E:/18111207351/pytorch")
#e, but got [324, 10] at entry 0 and [0, 10] at entry 15