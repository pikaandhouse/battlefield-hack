# -*-Encoding: utf-8 -*-
################################################################################
#
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Description: Prepare the experimental settings
"""
import torch


def prep_env():
    # type: () -> dict
    """
    Desc:
        Prepare the experimental settings
    Returns:
        The initialized arguments
    """
    settings = {
        "path_to_test_x": "E:/18111207351/test_x.csv",
        "path_to_test_y": "./data/sdwpf_baidukddcup2022_test_toy/test_y",
        "data_path": "data/",
        "filename": "data/wtbdata_245days.csv",
        "loc_file_name":"data/sdwpf_baidukddcup2022_turb_location.CSV",
        "task": "MS",
        "target": "Patv",
        "checkpoints": "",
        "input_len": 144,
        "output_len": 288,
        "start_col": 3,
        "in_var": 10,
        "out_var": 1,
        "day_len": 144,
        "train_size": 225,
        "val_size": 20,
        "test_size": 0,
        "total_size": 245,
        "lstm_layer": 4,
        "dropout": 0.3,
        "num_workers": 0,
        "train_epochs": 8,
        "batch_size":64 ,
        "patience": 5,
        "lr": 1e-5,
        "lr_adjust": "type1",
        "gpu": 0,
        "tur_loc": [0., 0., 0.],
        "capacity": 134,
        "turbine_id": 0,
        "pred_file": "predict.py",
        "c_out": 10, 
        "data":'SDWPF',
        "data_path":'data/sdwpf_baidukddcup2022_test_toy/test_x/',
        "debug":False, 
         "dec_crossattn":'full', 
         "dec_in":10, 
         "dec_selfattn":'full',
         "des":'test', 
         "do_predict":True, 
          "dropout":0.05,
          "model":'tcn', 
          "model_name":'base_model', 
         "out_inverse":False, 
          "out_size":1, 
 
        "framework": "pytorch",
       "is_debug": True,
    
        "is_debug": True
    }
    ###
    # Prepare the GPUs
    
    
    
    settings["use_gpu"] = True
    torch.device("cuda")
   

 
    return settings
