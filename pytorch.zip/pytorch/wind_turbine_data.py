
import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
# from sklearn.preprocessing import StandardScaler

from utils.tools import StandardScaler, timer
from utils.timefeatures import time_features
from joblib import Parallel, delayed
import warnings
warnings.filterwarnings('ignore')
import random 
from datetime import datetime, timedelta
from utils.tools import filter_extreme

class DatasetBase(Dataset):
    def __init__(self, args):
        self.args = args
        self.data_path = args.data_path
        self.seq_len, self.label_len, self.pred_len = args.seq_len, args.label_len, args.pred_len
        self.features = args.features
        self.file_name = args.file_name
        self.target = args.target
        self.scale = args.scale
        self.inverse = args.inverse
        self.freq = args.freq
        self.cols = args.cols
        self.horizon = args.horizon
        self.out_len = max(self.horizon, self.pred_len)
        self.timeenc = 0 if args.embed!='timeF' else 1
        self.start_col = args.start_col
        
    def get_idxs1(self, sample_id, shuffle=False):
        total_len, start_point = len(sample_id), sample_id[0]
        length = total_len - self.seq_len - self.out_len + 1
        cut_point1, cut_point2 = length-self.test_size-self.val_size, length-self.test_size
        border1s = [i+start_point for i in [0, cut_point1, cut_point2]]
        border2s = [i+start_point for i in [cut_point1, cut_point2, length]]
        train_idxs = np.arange(border1s[0], border2s[0]).tolist()
        val_idxs = np.arange(border1s[1], border2s[1]).tolist()
        train_val_idxs = train_idxs + val_idxs
        if shuffle:
            random.seed(125)
            random.shuffle(train_val_idxs)
        train_idxs, val_idxs = train_val_idxs[:len(train_idxs)], train_val_idxs[len(train_idxs):]
        test_idxs = np.arange(border1s[2], border2s[2])
        return train_idxs, val_idxs, test_idxs

    def get_idxs2(self, date):
        date = pd.to_datetime(date)
        delta = self.seq_len+self.out_len-1
        train_date = date[(date>="2012-01-01")&(date<=f"{self.test_year-2}-12-31")][:-delta]
        val_date = date[(date>train_date.values[-1]) & (date<=f"{self.test_year-1}-12-31")][:-delta]
        test_date = date[(date>val_date.values[-1]) & (date<=f"{self.test_year}-12-31")][:-delta]

        train_idxs  = date.index[np.where(date.isin(train_date))[0]];
        val_idxs = date.index[np.where(date.isin(val_date))[0]]
        test_idxs = date.index[np.where(date.isin(test_date))[0]]

        return train_idxs, val_idxs, test_idxs

class SDWPFDataSet(DatasetBase):
    def __init__(self, args,file_name):
        super().__init__(args)
        self.test_size = 15*24*6
        self.val_size = 16*24*6
        self.file_name=file_name
        self.__read_data__()
     

    def __read_data__(self):
        @timer
      
        def _get_data(shuffle=False):
            self.scaler = StandardScaler()
            # @cache_results(os.path.join(self.data_path, self.file_name[:-4], '.pkl'))
          #  print(os.path.join(self.data_path,"test_x.csv"))
            print(self.file_name+"**********")
            df_raw = pd.read_csv( self.file_name)
            def get_date(k):
                cur_date = "2020-01-01"
                one_day = timedelta(days=k-1)
                return str(datetime.strptime(cur_date, '%Y-%m-%d') + one_day)[:10]
            df_raw['Day'] = df_raw['Day'].apply(lambda x: get_date(x))

            def cols_concat(df, con_list):
                name = 'date'
                df[name] = df[con_list[0]].astype(str)
                for item in con_list[1:]:
                    df[name] = df[name] + ' ' + df[item].astype(str)
                return df

            df_raw = cols_concat(df_raw, ["Day", "Tmstamp"])
            df_raw = df_raw[['TurbID', 'date', 'Wspd', 'Wdir', 'Etmp', 'Itmp', 'Ndir', 'Pab1', 'Pab2', 'Pab3', 'Prtv', 'Patv']]
            df_raw['date'] = pd.to_datetime(df_raw['date'])

            # method 1
            sample_id_lst = [np.arange(len(df_raw))[df_raw["TurbID"]==i] 
                        for i in df_raw["TurbID"].unique()]
            _tmp = Parallel(n_jobs=-1)(delayed(self.get_idxs1)(x, shuffle) for x in sample_id_lst)
            train_idxs, val_idxs, test_idxs = zip(*_tmp)
            train_idxs, val_idxs, test_idxs = np.concatenate(train_idxs), np.concatenate(val_idxs), np.concatenate(test_idxs)
            df_raw = df_raw.drop(columns=["TurbID"])

            if isinstance(self.features, str):
                if self.features=='M' or self.features=='MS':
                    cols_data = df_raw.columns[self.start_col:]
                    df_data = df_raw[cols_data]
                elif self.features=='S':
                    df_data = df_raw[[self.target]]
            pd.set_option('mode.chained_assignment', None)
        
            df_data.replace(to_replace=np.nan, value=0.0, inplace=True)
          

            if self.scale:
                train_data = df_data.iloc[train_idxs]
                df_data, min_range, max_range = filter_extreme(df_data, "MAD", train_df = train_data)

                self.scaler.fit(df_data.iloc[train_idxs].values)
                data = self.scaler.transform(df_data.values)
            else:
                data = df_data.values
            df_stamp = df_raw[['date']]
            df_stamp = time_features(df_stamp, timeenc=self.timeenc, freq=self.freq)

            if self.inverse:
                data_y = df_data.values
            else:
                data_y = data
            return self.scaler, min_range, max_range, df_stamp, data, data_y, train_idxs, val_idxs, test_idxs
        shuffle = False
        self.scaler, self.min_range, self.max_range, self.data_stamp, self.data_x, self.data_y, \
        self.train_idxs, self.val_idxs, self.test_idxs = \
        _get_data(shuffle=shuffle)
        
    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len + self.horizon-1
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        if self.inverse:
            # encoder输入data_x,保持scaler，decoder输入data_y
            seq_y = np.concatenate([self.data_x[r_begin:r_begin+self.label_len], self.data_y[r_begin+self.label_len:r_end]], 0)
        else:
            seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]
     
        if(seq_x.shape==(0,10)):
            seq_x=torch.rand(144, 10)
           
        return dict(zip(["x", "y","x_mark", "y_mark" ],[seq_x, seq_y,seq_x_mark, seq_y_mark]))
    
    def __len__(self):
        return len(self.data_x) - self.seq_len- self.out_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)

