import torch
import yaml
from easydict import EasyDict as edict
from prepare import prep_env
from exp.exp_main import Exp_model
class EvaluationError(Exception):
    """
    Desc:
        Customize the Exception for Evaluation
    """
    def __init__(self, err_message):
        Exception.__init__(self, err_message)

def forecast(settings):
        con_path="config.yaml"
        config = edict(yaml.load(open(con_path), Loader=yaml.FullLoader))
        config.path_to_test_x= settings["path_to_test_x"]
       # raise EvaluationError("ggg") 
        config.use_gpu = True if torch.cuda.is_available() and config.use_gpu else False
        data_parser2 = {
            'ETTh1':{'data_path':'./data/ETT/', 'file_name':'ETTh1.csv',"dataset":"ETTh1",
            "freq":'h', #'seq_len':96, 'label_len':48, "pred_len":24, 
            "features":"M", 'T':'OT','M':[7,7,7],'S':[1,1,1],'MS':[7,7,1]},
            'ETTh2':{'T':'OT','M':[7,7,7],'S':[1,1,1],'MS':[7,7,1]},
            'ETTm1':{'T':'OT','M':[7,7,7],'S':[1,1,1],'MS':[7,7,1], "freq":'t'},
            'ETTm2':{'T':'OT','M':[7,7,7],'S':[1,1,1],'MS':[7,7,1]},
            'WTH':{'T':'WetBulbCelsius','M':[12,12,12],'S':[1,1,1],'MS':[12,12,1]},
            'ECL':{'T':'MT_320','M':[321,321,321],'S':[1,1,1],'MS':[321,321,1]},
            'Solar':{'T':'POWER_136','M':[137,137,137],'S':[1,1,1],'MS':[137,137,1]},
            'Mydata':{'freq':'b', 'T':'rv',"features":"MS", 'MS':[22,22,1],'M':[22,22,22]},
            "SDWPF":{'freq':'10min', 'T':'Patv',"features":"MS", 'MS':[10,10,1],'M':[10,10,10]},
            'Toy':{'data_path':'./data/ToyData', 'seq_len':96, 'label_len':0, "pred_len":24, "MS":[1,1,1], "T":"s"},
            'oze':{'seq_len':672, 'label_len':1, "pred_len":671, "M":[37,8,8], "T":"s", 'features':"M"}
        }

        if config.data in data_parser2.keys():
            data_info = data_parser2[config.data]
            config.features = data_info.get("features") or config.features
            config.enc_in, config.dec_in, config.out_size = data_info[config.features]
            config.data_path = data_info.get("data_path") or config.data_path
            config.file_name = data_info.get("file_name") or config.file_name
            config.dataset = data_info.get("dataset") or config.dataset
            config.horizon = data_info.get("horizon") or config.horizon
            config.single_file = data_info.get("single_file") if data_info.get("single_file") is not None else config.single_file
            config.seq_len = data_info.get('seq_len') or config.seq_len
            config.label_len = data_info.get('label_len') or config.label_len
            config.pred_len = data_info.get('pred_len') or config.pred_len
            config.target = data_info['T']

            if 'freq' in data_info:
                config.freq = data_info["freq"]
        config.input_size = config.enc_in
        config.test_activation = "softmax"
      
        config.path_to_test_x= settings["path_to_test_x"]
        setting_keys = '{}_{}_ty{}_ft{}_sl{}_ll{}_pl{}_is{}_os{}_hn{}_bs{}_lr{}_{}_{}'
        setting_values=[
                    config.model, config.dataset, config.test_year, config.features, 
                    config.seq_len, config.label_len, config.pred_len,
                    config.input_size, config.out_size, config.horizon,
                    config.batch_size, config.learning_rate,
                    config.des, 0]

        setting = setting_keys.format(*setting_values)
       # raise EvaluationError("1")
        exp = Exp_model(config, setting=setting, params_dict=None)
       # raise EvaluationError("2222")
        a=exp.test( config, load=config.load, plot=False)
        return np.array(a)
if __name__ == "__main__":
  se=prep_env()
  forecast(se)

   
