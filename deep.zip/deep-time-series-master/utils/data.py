from paddle import Tensor
from typing import TypeVar, List, Optional, Tuple, Sequence

from paddle.io import Dataset, Subset
T_co = TypeVar('T_co', covariant=True)
T = TypeVar('T')

from paddle import randperm
import paddle
from paddle.io import Sampler

class SubsetSequentialSampler(Sampler):
    r"""Samples elements Sequentially from a given list of indices, without replacement.

    Arguments:
        indices (sequence): a sequence of indices
        generator (Generator): Generator used in sampling.
    """
 

    def __init__(self, indices, generator=None) -> None:
        self.indices = indices
        self.generator = generator

    def __iter__(self):
        return (self.indices[i] for i in paddle.arange(len(self.indices)))

    def __len__(self):
        return len(self.indices)

class Subset(Dataset):
    r"""
    Subset of a dataset at specified indices.

    Arguments:
        dataset (Dataset): The whole Dataset
        indices (sequence): Indices in the whole set selected for subset
    """
 
    def __init__(self, dataset, indices) -> None:
        self.dataset = dataset
        self.indices = indices
        
    def __getitem__(self, idx):
        return self.dataset[self.indices[idx]]

    def __len__(self):
        return len(self.indices)

    def inverse_transform(self, x):
        if hasattr(self.dataset, "inverse_transform"):
            return self.dataset.inverse_transform(x)
        else:
            return x

