import paddle.nn as nn
import paddle
import paddle.nn.functional as F

class Swish(nn.Layer):
	def __init__(self):
		super(Swish, self).__init__()

	def forward(self, x):
		return x * paddle.sigmoid(x)

class Relu(nn.Layer):
	def __init__(self):
		super().__init__()

	def forward(self, x):
		return paddle.relu(x)

class Gelu(nn.Layer):
	def __init__(self):
		super().__init__()

	def forward(self, x):
		return F.gelu(x)