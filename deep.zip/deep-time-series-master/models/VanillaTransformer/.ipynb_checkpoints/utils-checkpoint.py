from typing import Optional, Union

import numpy as np
import paddle


def generate_original_PE(length: int, d_model: int) -> paddle.Tensor:
    """Generate positional encoding as described in original paper.  :class:`paddle.Tensor`

    Parameters
    ----------
    length:
        Time window length, i.e. K.
    d_model:
        Dimension of the model vector.

    Returns
    -------
        Tensor of shape (K, d_model).
    """
    PE = paddle.zeros((length, d_model))

    pos = paddle.arange(length).unsqueeze(1)
    PE[:, 0::2] = paddle.sin(
        pos / paddle.pow(1000, paddle.arange(0, d_model, 2, dtype=paddle.float32)/d_model))
    PE[:, 1::2] = paddle.cos(
        pos / paddle.pow(1000, paddle.arange(1, d_model, 2, dtype=paddle.float32)/d_model))

    return PE


def generate_regular_PE(length: int, d_model: int, period: Optional[int] = 24) -> paddle.Tensor:
    """Generate positional encoding with a given period.

    Parameters
    ----------
    length:
        Time window length, i.e. K.
    d_model:
        Dimension of the model vector.
    period:
        Size of the pattern to repeat.
        Default is 24.

    Returns
    -------
        Tensor of shape (K, d_model).
    """
    PE = paddle.zeros((length, d_model))

    pos = paddle.arange(length, dtype=paddle.float32).unsqueeze(1)
    PE = paddle.sin(pos * 2 * np.pi / period)
    PE = PE.repeat((1, d_model))

    return PE


def generate_local_map_mask(chunk_size: int,
                            attention_size: int,
                            mask_future=False,
                            device: paddle.device = 'cpu') -> paddle.BoolTensor:
    """Compute attention mask as attention_size wide diagonal.

    Parameters
    ----------
    chunk_size:
        Time dimension size.
    attention_size:
        Number of backward elements to apply attention.
    device:
        paddle device. Default is ``'cpu'``.

    Returns
    -------
        Mask as a boolean tensor.
    """
    local_map = np.empty((chunk_size, chunk_size))
    i, j = np.indices(local_map.shape)

    if mask_future:
        local_map[i, j] = (i - j > attention_size) ^ (j - i > 0)
    else:
        local_map[i, j] = np.abs(i - j) > attention_size

    return paddle.BoolTensor(local_map).to(device)
