import paddle
import paddle.nn as nn
from einops import rearrange, reduce, repeat


class DampingLayer(nn.Layer):

    def __init__(self, d_model, pred_len, nhead, dropout=0.1):
        super().__init__()
        self.pred_len = pred_len
        self.nhead = nhead
        self._damping_factor = (paddle.randn(shape= [1, nhead]))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = repeat(x, 'B () D -> B T D', T=self.pred_len)
        B, T, D = x.shape

        powers = paddle.arange(self.pred_len) + 1
        powers = powers.transpose((self.pred_len, 1))
        damping_factors = self.damping_factor ** powers
        damping_factors = damping_factors.cumsum(dim=0)
        x = x.transpose((B, T, self.nhead, -1))
        x = self.dropout(x) * damping_factors.unsqueeze(-1)
        return x.transpose((B, T, D))

    @property
    def damping_factor(self):
        return paddle.sigmoid(self._damping_factor)


class DecoderLayer(nn.Layer):

    def __init__(self, d_model, nhead, c_out, pred_len, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.nhead = nhead
        self.c_out = c_out
        self.pred_len = pred_len

        self.growth_damping = DampingLayer(d_model, pred_len, nhead, dropout=dropout)
        self.dropout1 = nn.Dropout(dropout)

    def forward(self, growth, season):
        growth_horizon = self.growth_damping(growth[:, -1:])
        growth_horizon = self.dropout1(growth_horizon)

        seasonal_horizon = season[:, -self.pred_len:]
        return growth_horizon, seasonal_horizon


class Decoder(nn.Layer):

    def __init__(self, layers):
        super().__init__()
        self.d_model = layers[0].d_model
        self.c_out = layers[0].c_out
        self.pred_len = layers[0].pred_len
        self.nhead = layers[0].nhead

        self.layers = nn.LayerList(layers)
        self.pred = nn.Linear(self.d_model, self.c_out)

    def forward(self, growths, seasons):
        growth_repr = []
        season_repr = []

        for idx, layer in enumerate(self.layers):
            growth_horizon, season_horizon = layer(growths[idx], seasons[idx])
            growth_repr.append(growth_horizon)
            season_repr.append(season_horizon)
        growth_repr = sum(growth_repr)
        season_repr = sum(season_repr)
        return self.pred(growth_repr), self.pred(season_repr)