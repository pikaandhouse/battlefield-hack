import paddle.nn as nn
import paddle.nn.functional as F


class ETSEmbedding(nn.Layer):
    def __init__(self, c_in, d_model, dropout=0.1):
        super().__init__()
        self.conv = nn.Conv1D(in_channels=c_in, out_channels=d_model,
                              kernel_size=3, padding=2, )
        self.dropout = nn.Dropout(p=dropout)
      

    def forward(self, x,):
        x=x.astype("float32")
        x = self.conv(x.transpose((0,2,1)))[..., :-2]
        return self.dropout(x.transpose((0,2,1)))


class Feedforward(nn.Layer):
    def __init__(self, d_model, dim_feedforward, dropout=0.1, activation='sigmoid'):
        # Implementation of Feedforward model
        super().__init__()
        self.linear1 = nn.Linear(d_model, dim_feedforward, )
        self.dropout1 = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model,)
        self.dropout2 = nn.Dropout(dropout)
        self.activation = getattr(F, activation)

    def forward(self, x):
        x = self.linear2(self.dropout1(self.activation(self.linear1(x))))
        return self.dropout2(x)