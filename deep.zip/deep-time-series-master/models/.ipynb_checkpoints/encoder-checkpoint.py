import paddle
import paddle.nn as nn
import paddle.nn.functional as F
import paddle.fft as fft

from einops import rearrange, reduce, repeat
import math, random

from .modules import Feedforward
from .exponential_smoothing import ExponentialSmoothing


class GrowthLayer(nn.Layer):

    def __init__(self, d_model, nhead, d_head=None, dropout=0.1):
        super().__init__()
        self.d_head = d_head or (d_model // nhead)
        self.d_model = d_model
        self.nhead = nhead

        self.z0 = (paddle.randn(  shape=[self.nhead, self.d_head]))
        self.in_proj = nn.Linear(self.d_model, self.d_head * self.nhead)
        self.es = ExponentialSmoothing(self.d_head, self.nhead, dropout=dropout)
        self.out_proj = nn.Linear(self.d_head * self.nhead, self.d_model)

        assert self.d_head * self.nhead == self.d_model, "d_model must be divisible by nhead"

    def forward(self, inputs):
        """
        :param inputs: shape: (batch, seq_len, dim)
        :return: shape: (batch, seq_len, dim)
        """
        B, T, D = inputs.shape
        values = self.in_proj(inputs).transpose((B, T, self.nhead, -1))
        values = paddle.concat([repeat(self.z0, 'H D -> B () H D', B=B), values], axis=1)
        values = values[:, 1:] - values[:, :-1]
        out = self.es(values)
        out = paddle.concat([repeat(self.es.v0, 'H D -> B () H D', B=B), out],  axis=1)
        out = rearrange(out, 'B T H D -> B T (H D)')
        return self.out_proj(out)


class FourierLayer(nn.Layer):

    def __init__(self, d_model, pred_len, k=None, low_freq=1):
        super().__init__()
        self.d_model = d_model
        self.pred_len = pred_len
        self.k = k
        self.low_freq = low_freq

    def forward(self, x):
        """x: (B T D)"""
        B, T, D = x.shape
        x_freq = fft.rfft(x,axis=1)

        if T % 2 == 0:
            x_freq = x_freq[:, self.low_freq:-1]
            f = fft.rfftfreq(T)[self.low_freq:-1]
        else:
            x_freq = x_freq[:, self.low_freq:]
            f = fft.rfftfreq(T)[self.low_freq:]

        x_freq, index_tuple = self.topk_freq(x_freq)
        f = repeat(f, 'F -> B F D', B=x_freq.shape[0], D=x_freq.shape[2])
        f = rearrange(f[index_tuple], 'B F D -> B F () D')

        return self.extrapolate(x_freq, f, T)

    def extrapolate(self, x_freq, f, T):
        x_freq = paddle.concat([x_freq, x_freq.conj()], axis=1)
        f = paddle.concat([f, -f], axis=1)
        t = rearrange(paddle.arange(T + self.pred_len, dtype='float32'),
                      'T -> () () T ()')

        amp = rearrange(x_freq.abs() / T, 'B F D -> B F () D')
        phase = rearrange(x_freq.angle(), 'B F D -> B F () D')
        amp=paddle.to_tensor(amp)
        phase=paddle.to_tensor(phase)
        x_time =paddle.cos(2 * math.pi * f * t + phase)

        return reduce(x_time, 'B F T D -> B T D', 'sum')

    def topk_freq(self, x_freq):
        values, indices = paddle.topk(x_freq.abs(), self.k, axis=1, largest=True, sorted=True)
        mesh_a, mesh_b = paddle.meshgrid(paddle.arange(x_freq.shape[0]), paddle.arange(x_freq.shape[2]))
       # indices=paddle.squeeze(indices,axis=1)
        a=paddle.to_tensor(mesh_a.unsqueeze(1),dtype='float32')
        b=paddle.to_tensor(indices,dtype='float32')
        c=paddle.to_tensor(mesh_b.unsqueeze(1),dtype='float32')
        index_tuple = (a,b,c)
        x_freq = x_freq[index_tuple]


        return x_freq, index_tuple


class LevelLayer(nn.Layer):

    def __init__(self, d_model, c_out, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.c_out = c_out

        self.es = ExponentialSmoothing(1, self.c_out, dropout=dropout, aux=True)
        self.growth_pred = nn.Linear(self.d_model, self.c_out)
        self.season_pred = nn.Linear(self.d_model, self.c_out)

    def forward(self, level, growth, season):
        B, T, _ = level.shape
        growth = self.growth_pred(growth).transpose((B, T, self.c_out, 1))
        season = self.season_pred(season).transpose((B, T, self.c_out, 1))
        growth = growth.transpose((B, T, self.c_out, 1))
        season = season.transpose((B, T, self.c_out, 1))
        level = level.transpose((B, T, self.c_out, 1))
        out = self.es(level - season, aux_values=growth)
        out = rearrange(out, 'B T H D -> B T (H D)')
        return out

class EncoderLayer(nn.Layer):

    def __init__(self, d_model, nhead, c_out, pred_len, k, dim_feedforward=None, dropout=0.1,
                 activation='sigmoid', layer_norm_eps=1e-5):
        super().__init__()
        self.d_model = d_model
        self.nhead = nhead
        self.c_out = c_out
        self.pred_len = pred_len
        dim_feedforward = dim_feedforward or 4 * d_model
        self.dim_feedforward = dim_feedforward

        self.growth_layer = GrowthLayer(d_model, nhead, dropout=dropout)
        self.seasonal_layer = FourierLayer(d_model, pred_len, k=k)
        self.level_layer = LevelLayer(d_model, c_out, dropout=dropout)

        # Implementation of Feedforward model
        self.ff = Feedforward(d_model, dim_feedforward, dropout=dropout, activation=activation)
        self.norm1 = nn.LayerNorm(d_model,epsilon=layer_norm_eps)
        self.norm2 = nn.LayerNorm(d_model, epsilon=layer_norm_eps)

        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, res, level, attn_mask=None):
        season = self._season_block(res)
        res = res - season[:, :-self.pred_len]
        growth = self._growth_block(res)
        res = self.norm1(res - growth[:, 1:])
        res = self.norm2(res + self.ff(res))

        level = self.level_layer(level, growth[:, :-1], season[:, :-self.pred_len])

        return res, level, growth, season

    def _growth_block(self, x):
        x = self.growth_layer(x)
        return self.dropout1(x)

    def _season_block(self, x):
        x = self.seasonal_layer(x)
        return self.dropout2(x)


class Encoder(nn.Layer):

    def __init__(self, layers):
        super().__init__()
        self.layers = nn.LayerList(layers)

    def forward(self, res, level, attn_mask=None):
        growths = []
        seasons = []
        for layer in self.layers:
            res, level, growth, season = layer(res, level, attn_mask=None)
            growths.append(growth)
            seasons.append(season)

        return level, growths, seasons