import torch 
import paddle

x = torch.randn([2, 3, 4])
print(x.shape)
x_transposed = x.transpose(-1,1)
print(x_transposed.shape)